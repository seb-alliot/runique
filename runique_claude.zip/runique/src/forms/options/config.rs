// Réservé pour futures configurations de champs spécialisés
// (les configurations actuelles sont intégrées directement dans chaque field)
