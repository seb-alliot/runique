pub const ADMIN_CSS: &[(&str, &[u8])] = &[
    ("variables.css",  include_bytes!("../../../static/css/admin/variables.css")),
    ("layout.css",     include_bytes!("../../../static/css/admin/layout.css")),
    ("components.css", include_bytes!("../../../static/css/admin/components.css")),
    ("buttons.css",    include_bytes!("../../../static/css/admin/buttons.css")),
    ("forms.css",      include_bytes!("../../../static/css/admin/forms.css")),
    ("login.css",      include_bytes!("../../../static/css/admin/login.css")),
    ("responsive.css", include_bytes!("../../../static/css/admin/responsive.css")),
    ("admin.js", include_bytes!("../../../static/js/admin/admin.js")),
];
